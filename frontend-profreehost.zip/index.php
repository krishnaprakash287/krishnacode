<?php
// NEXGEN CODE - Frontend Entrypoint for ProFreeHost / Apache
if (file_exists(__DIR__ . '/index.html')) {
    readfile(__DIR__ . '/index.html');
    exit;
}
?>
